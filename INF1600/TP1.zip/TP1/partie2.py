iteration = 8
valeur = 10
constante = 1

for i in range(0, iteration, constante):
    valeur -= constante
    
print(valeur)