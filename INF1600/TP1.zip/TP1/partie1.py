valeur = 1015
seuil = 985
constante = 8
result = 0

if (valeur == seuil):
    result = valeur * constante
    
else:
    result = valeur - constante
    
print(result)

